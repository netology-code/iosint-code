//
// ViewController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 03.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

class ViewController: UIViewController {
    
//    let notificationCenter = NotificationCenter.default
    var publisher: Publisher?
    
    private let label: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = .blue
        label.backgroundColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        layout()
        publisher?.add(observer: self)
        
        
//        notificationCenter.addObserver(
//            forName: .observerNotification,
//            object: nil,
//            queue: nil) { notification in
//            guard let dictionary = notification.userInfo as? [String: String] else { return }
//            if let value = dictionary["key"] {
//                self.label.text = value
//            }
//        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        publisher?.remove { _ in
            return true
        }
    }
    
    private func layout() {
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }
}

extension ViewController: Observer {
    func receiveData(text: Dictionary<String, String>) {
        if let value = text["key"] {
            label.text = value
        }
    }
}

