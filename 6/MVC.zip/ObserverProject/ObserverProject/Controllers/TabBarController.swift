//
// TabBarController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

final class TabBarController: UITabBarController {
    
    var publisher: Publisher
    
    init(publisher: Publisher) {
        self.publisher = publisher
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let viewController = ViewController()
        let navigationFirst = UINavigationController(rootViewController: viewController)
        navigationFirst.tabBarItem = UITabBarItem(
            title: "First",
            image: UIImage(named: "first"),
            selectedImage: nil)
        let feedController = FeedController()
        let navigationSecond = UINavigationController(rootViewController: feedController)
        navigationSecond.tabBarItem = UITabBarItem(
            title: "Feed",
            image: UIImage(named: "feed"),
            selectedImage: nil)
        
        
        let model = SettingsModel(publisher: publisher)
        let settingsController = SettingsController(model: model)
        let navigationThird = UINavigationController(rootViewController: settingsController)
        navigationThird.tabBarItem = UITabBarItem(
            title: "Settings",
            image: UIImage(named: "settings"),
            selectedImage: nil)
        viewControllers = [navigationFirst, navigationSecond, navigationThird]
    }
}
