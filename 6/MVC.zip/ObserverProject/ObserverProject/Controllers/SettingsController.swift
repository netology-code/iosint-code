//
// SettingsController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

// Слой Presentation: M-V-C (V + C)

final class SettingsController: UIViewController {
    
    private lazy var settingsButton: SettingsButton = {
        let button = SettingsButton {
            self.inputData()
        }
        button.setTitle("PRESS ME", for: .normal)
        button.setTitleColor(.cyan, for: .normal)
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.green.cgColor
        
        return button
    }()
    
    private lazy var textInput: TextInput = {
        let textInput = TextInput(placeholder: "какой-то текст") { [weak self] text in
            self?.textStorage = text
        }
        textInput.layer.borderWidth = 1
        textInput.layer.borderColor = UIColor.yellow.cgColor
        textInput.textColor = .cyan

        return textInput
    }()
    
    private var model: ModelInput
    private var textStorage: String = ""
    
    init(model: ModelInput) {
        self.model = model
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .darkGray
        layout()
    }
    
    private func layout() {
        view.addSubview(textInput)
        view.addSubview(settingsButton)
        
        NSLayoutConstraint.activate([
            settingsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            settingsButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -100),
            settingsButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75),
            textInput.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            textInput.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            textInput.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75),
        ])
    }
    
    private func inputData() {
        let array = [textStorage, textStorage, textStorage]
        let dict = ["key": array]
        model.updateModel(dict)
    }
}
