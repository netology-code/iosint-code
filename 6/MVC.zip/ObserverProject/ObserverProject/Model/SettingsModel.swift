//
// SettingsModel.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import Foundation

protocol ModelInput {
    func updateModel(_ with: [String: [String]])
}

class SettingsModel: ModelInput {
    
    var settings: [String: [String]] = [:]
    var publisher: Publisher
    
    init(publisher: Publisher) {
        self.publisher = publisher
    }
    
    func updateModel(_ dict: [String : [String]]) {
        publisher.sendData(data: dict)
    }
    
    
}
