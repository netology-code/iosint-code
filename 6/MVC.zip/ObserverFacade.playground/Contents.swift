
import Foundation

/// **OBSERVER / НАБЛЮДАТЕЛЬ**

protocol Publishing: NSObject {
    func updateString(text: String)
    func updateDate(date: Date)
}

protocol Observing {
    var observations: [NSKeyValueObservation] { get }
    func killObservations()
}

class ObservableClass: NSObject, Publishing {
    
    // 1. наши специфичные переменные для KVO
    
    @objc dynamic private(set) var string = ""
    
    @objc dynamic private(set) var dynamicDate = Date()
    
    // 2. методы интерфейса для обновления состояния
    
    func updateString(text: String) {
        string = text
    }
    
    func updateDate(date: Date) {
        dynamicDate = date
    }
}

class ObserverString: Observing {
    
    private(set) var observations: [NSKeyValueObservation] = []
    
    func observeString(publisher: ObservableClass) {
        let observation = publisher.observe(\.string, options: [.old, .new]) { _, value in
            print("Old value \(String(describing: value.oldValue)) New value \(String(describing: value.newValue))")
        }
        observations.append(observation)
    }
    
    func killObservations() {
        observations = []
    }
    
    deinit {
        killObservations()
    }
}

class ObserverDate: Observing {
    
    private let dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.timeStyle = .short
        df.dateStyle = .medium
        df.locale = Locale(identifier: "ru_RU")
        return df
    }()
    
    // 3. надо хранить сильные(?) ссылки на объекты наблюдения
    private(set) var observations: [NSKeyValueObservation] = []
    
    func observeDate(publisher: ObservableClass) {
        let observation = publisher.observe(\.dynamicDate, options: .new) { _, date in
            print(self.dateFormatter.string(from: date.newValue!))
        }
        observations.append(observation)
    }
    
    
    // 4. не забывать чистить ссылки
    func killObservations() {
        observations = []
    }
    
    deinit {
        killObservations()
    }
}

let publisher = ObservableClass()

let observerString = ObserverString()
observerString.observeString(publisher: publisher)

let observerDate = ObserverDate()
observerDate.observeDate(publisher: publisher)

publisher.updateString(text: "Mary")
publisher.updateString(text: "Peter")
publisher.updateString(text: "Low cost flight")

publisher.updateDate(date: Date(timeIntervalSinceNow: 5200))
publisher.updateDate(date: Date(timeIntervalSinceNow: 36400))

