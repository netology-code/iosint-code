//
// SettingsCoordinator.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

final class SettingsCoordinator: Coordinator {
    var coordinators: [Coordinator] = []
    let navigationController: UINavigationController
    
    private let factory: ControllerFactory
    private lazy var settingsModule = {
        factory.makeSettings()
    }()
    
    init(navigation: UINavigationController,
         factory: ControllerFactory) {
        self.navigationController = navigation
        self.factory = factory
    }
    
    func start() {
        
        // обратная связь SettingsModule
        settingsModule.viewModel.onShowNext = { [weak self] in
            guard let controller = self?.configureNext() else { return }
            self?.navigationController.pushViewController(controller, animated: true)
        }
        
        navigationController.pushViewController(settingsModule.controller, animated: true)
    }
    
    // конфигурация NextModule
    private func configureNext() -> NextController {
        return factory.makeNext().controller
    }
}
