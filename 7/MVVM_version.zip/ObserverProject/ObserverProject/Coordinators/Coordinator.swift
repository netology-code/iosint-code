//
// Coordinator.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

protocol Coordinator: AnyObject {
    var coordinators: [Coordinator] { get set }
}
