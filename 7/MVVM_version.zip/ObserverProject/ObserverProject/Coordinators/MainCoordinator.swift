//
// MainCoordinator.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

class MainCoordinator: Coordinator {
    
    var coordinators: [Coordinator] = []
    let tabBarController: TabBarController
    private let factory = ControllerFactoryImpl()
    
    init() {
        tabBarController = TabBarController()
        
        let firstModule = configureFirst()
        let feedModule = configureFeed()
        let settingsCoordinator = configureSettings()
        coordinators.append(settingsCoordinator)
        
        tabBarController.viewControllers = [firstModule, feedModule, settingsCoordinator.navigationController]
        settingsCoordinator.start()
    }
    
    private func configureFirst() -> UINavigationController {
        
        let viewController = ViewController()
        let navigationFirst = UINavigationController(rootViewController: viewController)
        navigationFirst.tabBarItem = UITabBarItem(
            title: "First",
            image: UIImage(named: "first"),
            selectedImage: nil)
        return navigationFirst
    }
    
    private func configureFeed() -> UINavigationController {
        let feedController = FeedController()
        let navigationSecond = UINavigationController(rootViewController: feedController)
        navigationSecond.tabBarItem = UITabBarItem(
            title: "Feed",
            image: UIImage(named: "feed"),
            selectedImage: nil)
        return navigationSecond
    }
    
    private func configureSettings() -> SettingsCoordinator {
        
        let navigationThird = UINavigationController()
        navigationThird.tabBarItem = UITabBarItem(
            title: "Settings",
            image: UIImage(named: "settings"),
            selectedImage: nil)
        let coordinator = SettingsCoordinator(
            navigation: navigationThird,
            factory: factory)
        
        return coordinator
    }
}
