//
// SettingsController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

// Слой Presentation

final class SettingsController: UIViewController {
    
    private lazy var settingsButton: SettingsButton = {
        let button = SettingsButton {
            self.inputData()
        }
        button.setTitle("PRESS ME", for: .normal)
        button.setTitleColor(.cyan, for: .normal)
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.green.cgColor
        
        return button
    }()
    
    private lazy var showModuleButton: SettingsButton = {
        let button = SettingsButton {
            self.showNextModule()
        }
        button.setTitle("Show Module", for: .normal)
        button.setTitleColor(.yellow, for: .normal)
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.blue.cgColor
        button.layer.cornerRadius = 4
        
        return button
    }()
    
    private lazy var textInput: TextInput = {
        let textInput = TextInput(placeholder: "какой-то текст") { [weak self] text in
            self?.textStorage = text
        }
        textInput.layer.borderWidth = 1
        textInput.layer.borderColor = UIColor.yellow.cgColor
        textInput.textColor = .cyan

        return textInput
    }()
    
    private var viewModel: SettingsViewOutput
    private var textStorage: String = ""
    
    init(viewModel: SettingsViewOutput) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .darkGray
        layout()
    }
    
    private func layout() {
        view.addSubview(textInput)
        view.addSubview(settingsButton)
        view.addSubview(showModuleButton)
        
        NSLayoutConstraint.activate([
            settingsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            settingsButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -100),
            settingsButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75),
            textInput.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            textInput.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            textInput.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75),
            showModuleButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            showModuleButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 100),
            showModuleButton.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.5)
        ])
    }
    
    private func inputData() {
        viewModel.updateModel(textStorage)
    }
    
    private func showNextModule() {
      // мы попросим viewModel передать touch event о том, что нужно показать другой модуль
        viewModel.onTapShowNextModule()
    }
}
