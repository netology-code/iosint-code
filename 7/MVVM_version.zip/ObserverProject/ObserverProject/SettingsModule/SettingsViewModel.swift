//
// SettingsViewModel.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

protocol SettingsViewOutput {
    var onTapShowNextModule: () -> Void { get }
    func updateModel(_ string: String)
}

// MVVM: часть модуля - ViewModel

class SettingsViewModel: SettingsViewOutput {
    
    // интерфейс для отправки данных в координатор
    var onShowNext: (() -> Void)?
    
    // интерфейс для приема данных от ViewController
    lazy var onTapShowNextModule: () -> Void = { [weak self] in
        self?.onShowNext?()
    }
    
    // метод трансформирует данные
    func updateModel(_ string: String) {
        let integerArray = [3, 5, 7]
        guard let index = integerArray.randomElement() else { return }
        let array = Array(repeating: string, count: index)
        let dict = ["key": array]
    }
}
