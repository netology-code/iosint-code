//
// Publisher.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 03.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import Foundation

protocol Observer {
    func receiveData(text: Dictionary<String, Array<String>>)
}

// Слой бизнес-логики или МОДЕЛЬ

final class Publisher {
    
    private var observers: [Observer] = []
    
    let notificationCenter = NotificationCenter.default
    
    func publishNotification(info: Dictionary<String, String>) {
        let notification = Notification(
            name: .observerNotification,
            object: nil,
            userInfo: info)
        notificationCenter.post(notification)
    }
    
    func add(observer: Observer) {
        observers.append(observer)
    }
    
    func remove(observer filter: (Observer) -> Bool) {
        guard let index = observers.firstIndex(where: filter) else { return }
        observers.remove(at: index)
    }
    
    func sendData(data: Dictionary<String, Array<String>>) {
        observers.forEach {
            $0.receiveData(text: data)
        }
    }
}

extension Notification.Name {
    static var observerNotification: Notification.Name {
        return .init(rawValue: "Observer Notification")
    }
}
