//
// ControllerFactory.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

protocol ControllerFactory {
    func makeSettings() -> (viewModel: SettingsViewModel, controller: SettingsController)
    
    func makeNext() -> (viewModel: NextViewModel, controller: NextController)
}

struct ControllerFactoryImpl: ControllerFactory {
    func makeNext() -> (viewModel: NextViewModel, controller: NextController) {
        let viewModel = NextViewModel()
        let controller = NextController(viewModel: viewModel)
        return (viewModel, controller)
    }
    
    
    func makeSettings() -> (viewModel: SettingsViewModel, controller: SettingsController) {
        let viewModel = SettingsViewModel()
        let settingsController = SettingsController(viewModel: viewModel)
        return (viewModel, settingsController)
    }
}
