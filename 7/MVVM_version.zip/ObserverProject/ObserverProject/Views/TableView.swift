//
// TableView.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

final class TableView: UITableView {
    
    init(dataSource: UITableViewDataSource,
         delegate: UITableViewDelegate) {
        super.init(frame: .zero, style: .plain)
        self.dataSource = dataSource
        self.delegate = delegate
        translatesAutoresizingMaskIntoConstraints = false
        register(UITableViewCell.self, forCellReuseIdentifier: String(describing: UITableViewCell.self))
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
