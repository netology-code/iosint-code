//
// NextController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

final class NextController: UIViewController {
    
    private var viewModel: NextViewOutput
    
    init(viewModel: NextViewOutput) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel.moduleTitle
        view.backgroundColor = .magenta
    }
    
}
