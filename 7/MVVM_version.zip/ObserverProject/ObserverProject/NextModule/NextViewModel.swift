//
// NextViewModel.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 10.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

protocol NextViewOutput {
    var moduleTitle: String { get }
}

final class NextViewModel: NextViewOutput {
    var moduleTitle: String {
        return "NEXT MODULE"
    }
}
