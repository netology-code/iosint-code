//
// ViewController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 03.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

class ViewController: UIViewController {
    
    var publisher: Publisher?
    
    private var dataSource: Array<String>? {
        didSet {
            tableView.reloadData()
        }
    }
    
    private lazy var tableView = TableView(dataSource: self, delegate: self)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        layout()
        publisher?.add(observer: self)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    deinit {
        publisher?.remove { _ in
            return true
        }
    }
    
    private func layout() {
        view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
}

extension ViewController: Observer {
    func receiveData(text: Dictionary<String, Array<String>>) {
        if let value = text["key"] {
            dataSource = value
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let rows = dataSource?.count {
            return rows
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        if let dataSource = dataSource {
            cell.textLabel?.text = dataSource[indexPath.row]
            return cell
        } else {
            cell.detailTextLabel?.text = "empty"
            return cell
        }
    }
}

extension ViewController: UITableViewDelegate {
    
}
