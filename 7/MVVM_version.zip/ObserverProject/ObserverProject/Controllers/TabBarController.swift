//
// TabBarController.swift
// ObserverProject
// 
// Created by Maxim Abakumov on 2021. 06. 07.
//
// Copyright © 2020, Maxim Abakumov. MIT License.
//

import UIKit

final class TabBarController: UITabBarController {
}

