//
//  HabitTracksViewController.swift
//  MyHabits
//
//  Created by Artem Novichkov on 10.10.2020.
//

import UIKit

class HabitTracksViewController: UIViewController {
    
    var habit: Habit?
    
    let store: HabitsStore = .shared

    @IBOutlet weak var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        title = habit?.name
        tableView.reloadData()
    }
    
    @IBAction func edit(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        let navigationViewController = storyboard.instantiateViewController(identifier: "habit") as! UINavigationController
        if let habitViewController = navigationViewController.viewControllers.first as? HabitViewController {
            habitViewController.deleteHandler = { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            }
            habitViewController.habit = habit
        }
        present(navigationViewController, animated: true, completion: nil)
    }
}

extension HabitTracksViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        store.dates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "habit_track", for: indexPath) as! HabitDateTableViewCell
        cell.textLabel?.text = store.trackDateString(forIndex: indexPath.row)
        if let habit = habit {
            cell.checkImageView.isHidden = store.habit(habit, isTrackedIn: store.dates[indexPath.row]) == false
            cell.checkImageView.tintColor = habit.color
        }
        else {
            cell.checkImageView.isHidden = true
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        "Активность"
    }
}

extension HabitTracksViewController: UITableViewDelegate {
    
}
