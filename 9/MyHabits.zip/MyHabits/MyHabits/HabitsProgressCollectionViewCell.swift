//
//  HabitTableViewCell.swift
//  MyHabits
//
//  Created by Artem Novichkov on 08.10.2020.
//

import UIKit

class HabitsProgressCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var progressView: UIProgressView!
}
