//
//  HabitViewController.swift
//  MyHabits
//
//  Created by Artem Novichkov on 08.10.2020.
//

import UIKit

class HabitViewController: UIViewController {
    
    let store: HabitsStore = .shared
    
    var habit: Habit?
    
    var deleteHandler: (() -> Void)?

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var deleteButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = habit == nil ? "Создать" : "Править"
        self.colorView.layer.cornerRadius = self.colorView.bounds.height / 2
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(showColorPicker))
        colorView.addGestureRecognizer(recognizer)
        if let habit = habit {
            self.nameTextField.text = habit.name
            self.colorView.backgroundColor = habit.color
            self.deleteButton.isHidden = false
        }
        else {
            self.deleteButton.isHidden = true
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func save(_ sender: Any) {
        if let habit = habit {
            habit.name = nameTextField.text ?? ""
            habit.date = datePicker.date
            habit.color = colorView.backgroundColor ?? .white
            store.save()
        }
        else {
            let newHabit = Habit(name: nameTextField.text ?? "",
                                 date: datePicker.date,
                                 trackDates: [],
                                 color: colorView.backgroundColor ?? .white)
            store.habits.append(newHabit)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func deleteHabit(_ sender: Any) {
        guard let habit = habit else {
            return
        }
        let alertController = UIAlertController(title: "Удалить привычку",
                                                message: "Вы хотите удалить привычку \"\(habit.name)\"?",
                                                preferredStyle: .alert)
        alertController.addAction(.init(title: "Отмена", style: .cancel, handler: nil))
        alertController.addAction(.init(title: "Удалить", style: .default) { _ in
            if let index = self.store.habits.firstIndex(of: habit) {
                self.store.habits.remove(at: index)
            }
            self.deleteHandler?()
            self.dismiss(animated: true, completion: nil)
        })
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc private func showColorPicker() {
        let controller = UIColorPickerViewController()
        controller.delegate = self
        present(controller, animated: true, completion: nil)
    }
}

extension HabitViewController: UIColorPickerViewControllerDelegate {
    
    
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        self.colorView.backgroundColor = viewController.selectedColor
    }
}
