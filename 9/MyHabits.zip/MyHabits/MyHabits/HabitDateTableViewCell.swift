//
//  HabitTableViewCell.swift
//  MyHabits
//
//  Created by Artem Novichkov on 08.10.2020.
//

import UIKit

class HabitDateTableViewCell: UITableViewCell {

    @IBOutlet weak var checkImageView: UIImageView!
}
