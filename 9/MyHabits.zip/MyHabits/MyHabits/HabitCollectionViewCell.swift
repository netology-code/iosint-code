//
//  HabitTableViewCell.swift
//  MyHabits
//
//  Created by Artem Novichkov on 08.10.2020.
//

import UIKit

class HabitCollectionViewCell: UICollectionViewCell {
    
    var trackHandler: (() -> Void)?

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var trackButton: UIButton!

    @IBAction func track(_ sender: Any) {
        trackHandler?()
    }
}
