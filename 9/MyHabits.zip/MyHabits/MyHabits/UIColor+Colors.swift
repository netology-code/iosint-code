//
//  UIColor+Colors.swift
//  MyHabits
//
//  Created by Artem Novichkov on 20.10.2020.
//

import UIKit

extension UIColor {

    static let grey = UIColor(red: 142 / 255, green: 142 / 255, blue: 147 / 255, alpha: 1)
    static let grey2 = UIColor(red: 174 / 255, green: 174 / 255, blue: 178 / 255, alpha: 1)
    static let bgColor = UIColor(red: 242 / 255, green: 242 / 255, blue: 247 / 255, alpha: 1)
}
