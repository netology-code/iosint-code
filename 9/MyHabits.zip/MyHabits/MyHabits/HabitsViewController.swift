//
//  ViewController.swift
//  MyHabits
//
//  Created by Artem Novichkov on 08.10.2020.
//

import UIKit

final class HabitsViewController: UIViewController {
    
    let store: HabitsStore = .shared
    
    @IBOutlet weak var collectionView: UICollectionView!
//    @IBOutlet weak var placeholderLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.alwaysBounceVertical = true
        collectionView.contentInset = .init(top: 22, left: 16, bottom: 22, right: 16)
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.collectionView.backgroundColor = .bgColor
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        placeholderLabel.isHidden = !store.habits.isEmpty
        collectionView.isHidden = store.habits.isEmpty
        collectionView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "habit_tracks" else {
            return
        }
        guard let habitTracksViewController = segue.destination as? HabitTracksViewController else {
            return
        }
        habitTracksViewController.habit = sender as? Habit
    }
    
    @IBAction func add(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        let navigationViewController = storyboard.instantiateViewController(identifier: "habit") as! UINavigationController
        present(navigationViewController, animated: true, completion: nil)
    }
}

extension HabitsViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard indexPath.row > 0 else {
            return
        }
        let habit = store.habits[indexPath.row - 1]
        self.performSegue(withIdentifier: "habit_tracks", sender: habit)
    }
}

extension HabitsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        store.habits.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "progress", for: indexPath) as!
                HabitsProgressCollectionViewCell
            cell.contentView.backgroundColor = .white
            cell.contentView.layer.cornerRadius = 4
            cell.titleLabel.text = "Всё получится!"
            cell.titleLabel.textColor = .grey
            let progress = Int(store.todayProgress * 100)
            cell.progressLabel.text = "\(progress)%"
            cell.progressLabel.textColor = .grey
            cell.progressView.progress = store.todayProgress
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "habit", for: indexPath) as! HabitCollectionViewCell
        let habit = store.habits[indexPath.row - 1]
        
        cell.contentView.backgroundColor = .white
        cell.contentView.layer.cornerRadius = 8
        
        cell.titleLabel.text = habit.name
        cell.titleLabel.textColor = habit.color
        
        cell.timeLabel.text = habit.dateString
        cell.timeLabel.textColor = .grey2
        
        cell.descriptionLabel.text = "Подряд: \(habit.trackDates.count)"
        cell.descriptionLabel.textColor = .grey2
        
        cell.trackButton.layer.cornerRadius = 18
        cell.trackButton.layer.borderWidth = 2
        cell.trackButton.layer.borderColor = habit.color.cgColor
        cell.trackButton.backgroundColor = habit.isAlreadyTakenToday ? habit.color : .clear
        
        cell.trackHandler = { [weak self] in
            if habit.isAlreadyTakenToday {
                return
            }
            self?.store.track(habit)
            self?.collectionView.reloadData()
        }
        return cell
    }
}

extension HabitsViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width - collectionView.contentInset.left - collectionView.contentInset.right
        let height: CGFloat = indexPath.row == 0 ? 60 : 130
        return .init(width: width, height: height)
    }
}
