import UIKit

/// **DELEGATE**

// 2.
class MyClass {
    
    // 3.
    weak var delegate: MyClassDelegate?
    
    func usefulFunc(parameter: Int) -> String {
        
        // 4.
        guard let string = delegate?.doUsefulWork(
            parameter: parameter
        ) else { return "" }
        
        return "Total " + string
    }
}

// 1.
protocol MyClassDelegate: AnyObject {
    func doUsefulWork(parameter: Int) -> String
}


class Worker: MyClassDelegate {
    
    // 5.
    func doUsefulWork(parameter: Int) -> String {
        return "WORK IS DONE \(parameter * 10) times"
    }
}

class Builder: MyClassDelegate {
    
    func doUsefulWork(parameter: Int) -> String {
        return "Built \(parameter * 1000) blocks"
    }
}

class Main {
    
    init() {
        let myClass = MyClass()
//        let myDelegate = Worker()
        let myBuilder = Builder()
        myClass.delegate = myBuilder
        print(myClass.usefulFunc(parameter: 44))
    }
}

let main = Main()


/// **SINGLETON**

let defaults = UserDefaults.standard
let center = NotificationCenter.default
let application = UIApplication.shared

class MySingleton {
    
    static let shared = MySingleton()
    
    private let property = "Password"
    
    private init() {
        
    }
    
    func checkInfo(parameter string: String) {
        if string == property {
            print("TRUE")
        } else {
            print("WRONG!!!")
        }
    }
}

MySingleton.shared.checkInfo(parameter: "Password")

extension MySingleton: NSCopying {
    func copy(with zone: NSZone? = nil) -> Any {
        return self
    }
}

/// **FACTORY**

struct Message {
    let text: String
}

struct MessageSender {
    let session = URLSession.shared
    let messages: [Message]
    
    init(messages: [Message]) {
        self.messages = messages
    }
}

class MyViewController: UIViewController {
    
    private let factory: Messaging
    
    init(factory: Messaging) {
        self.factory = factory
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension MyViewController {
    func dataSourceFunction() -> [String]{
        let sender = factory.makeSender()
        let messages = sender.messages
        return messages.map { $0.text }
    }
}

protocol Messaging {
    func makeSender() -> MessageSender
}

struct MessageFactory: Messaging {
    func makeSender() -> MessageSender {
        return MessageSender(messages: [])
    }
}
